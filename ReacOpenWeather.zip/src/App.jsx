import { useState, useEffect } from "react"; //importo useState para los estados y useEffect para los efectos
import axios from "axios";

import "./App.css";
import WeatherSearch from "./components/WeatherSearch";
import WeatherDisplay from "./components/WeatherDisplay";

function App() {
  const [city, setCity] = useState(""); //estado para guardar la ciudad a consultar
  const [weatherData, setWeatherData] = useState(null);
  const [error, setError] = useState(null);

  const apiKey = import.meta.env.VITE_OPENWEATHER_API_KEY;

  const fetchWeather = async (cityName) => {
    setError(null); //reseteamos errores previos
    setWeatherData(null); //limpiamos datos anteriores

    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=${apiKey}&units=metric`;
    try {
      const response = await axios.get(apiUrl);
      setWeatherData(response.data);
      console.log(weatherData);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    fetchWeather("bello");
  }, []);

  //console.log(weatherData);

  return (
    <>
      <h1 className="text-red-500">hola</h1>
      <WeatherSearch city={city} setCity={setCity} onSearch={fetchWeather} />
      <WeatherDisplay weatherData={weatherData} />
    </>
  );
}

export default App;
