const WeatherSearch = ({ city, setCity, onSearch }) => {
  //recibo estado y setEstado como props e igual la funcion de busqueda

  const handleInputChange = (e) => {
    //esta funcion al ser de un input recibe un evento "e"
    setCity(e.target.value); //actualizamos el estado con el valor del input
  };

  const handleSubmit = (e) => {
    //esta funcion captura el envio del formulario
    e.preventDefault(); //esto hace que la pagina no se recargue al enviar el formulario
    onSearch(city.trim());
  };
  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Escribe una ciudad..."
        onChange={handleInputChange}
      />
      <button type="submit">Consultar</button>
    </form>
  );
};

export default WeatherSearch;
